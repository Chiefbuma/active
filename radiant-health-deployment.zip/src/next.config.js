// This file is intentionally left blank to prevent build conflicts.
// The primary configuration is in the root next.config.js file.
module.exports = {};

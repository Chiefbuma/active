import type { NextConfig } from 'next';

// This file is intentionally left blank. 
// The primary configuration is now in next.config.js to resolve build conflicts.
const nextConfig: NextConfig = {};

export default nextConfig;
